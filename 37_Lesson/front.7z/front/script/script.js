elem.onclick = function() {
    
  };